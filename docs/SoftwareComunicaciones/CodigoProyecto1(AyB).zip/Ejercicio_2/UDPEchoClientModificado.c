#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>
#include "Practical.h"

int main(int argc, char *argv[]) {
	if (argc < 2 || argc > 3) // Test for correct number of arguments
		DieWithUserMessage("Parametros", "<Direccion del servidor> <Puerto>");

	char *server = argv[1];     // First arg: server address/name
	
	char echoString[100];
  	printf("Pregunta para el servidor: ");
  	scanf("%[^\n]", echoString);
  	size_t echoStringLen = strlen(echoString);
  	printf("Tengo un palabra de tamaño %ld \n", echoStringLen);

	// Third arg (optional): server port/service
	char *servPort = (argc == 3) ? argv[2] : "echo";

	// Tell the system what kind(s) of address info we want
	struct addrinfo addrCriteria;                   // Criteria for address match
	memset(&addrCriteria, 0, sizeof(addrCriteria)); // Zero out structure
	addrCriteria.ai_family = AF_UNSPEC;             // Any address family
	// For the following fields, a zero value means "don't care"
	addrCriteria.ai_socktype = SOCK_DGRAM;          // Only datagram sockets
	addrCriteria.ai_protocol = IPPROTO_UDP;         // Only UDP protocol

	// Get address(es)
	struct addrinfo *servAddr; // List of server addresses
	int rtnVal = getaddrinfo(server, servPort, &addrCriteria, &servAddr);
  
	// 1) Direccion del servidor (puende darme una IPv4, IPv6 o um hostname)
	// 2) El puerto o nombre de servicio
	// 3) Pistas(hints) definiendo un criterio para qeu me devuelva cierto tipo de direcciones
	// 4) donde almacenare la direccion resultante
	if (rtnVal != 0)
		DieWithUserMessage("getaddrinfo() ha fallado", gai_strerror(rtnVal));
	printf("La direccion se ha convertido con existo \n");

  	// Create a datagram/UDP socket
  	int sock = socket(servAddr->ai_family, servAddr->ai_socktype, servAddr->ai_protocol);
  	if (sock < 0)
    		DieWithSystemMessage("socket() ha fallado");
    	printf("Socket creado con existo \n");
    	printf("El identificador del socket es %d \n", sock); //NO es el numero de puerto
  
  	// Send the string to the server
  	ssize_t numBytes = sendto(sock, echoString, echoStringLen, 0, servAddr->ai_addr, servAddr->ai_addrlen);
  	//Sendto en via igual que hacia (4 parametros) en TPC pero tiene dos parametros mas
  		//5) direccion a enviar
  		//6) la longitud de la direcciona al que quiero enviar

 	if (numBytes < 0)
    		DieWithSystemMessage("sendto() ha fallado");
    	memset(echoString, 0, echoStringLen);

  	// Receive a response
  	// Source address of server
  	struct sockaddr_storage fromAddr;
  	
  	// Set length of from address structure (in-out parameter)
  	socklen_t fromAddrLen = sizeof(fromAddr);
  	
  	char buffer[MAXSTRINGLENGTH + 1];
  	//Igual que recv en TCP
  		//5) direccion desde la que me llega el mesaje
  		//6) longitud desde la que me llega el mesaje
  		
  	numBytes = recvfrom(sock, buffer, MAXSTRINGLENGTH, 0, (struct sockaddr *) &fromAddr, &fromAddrLen);
  	if (numBytes < 0)
   		DieWithSystemMessage("recvfrom() failed");

  	// Verify reception from expected source
  	if (!SockAddrsEqual(servAddr->ai_addr, (struct sockaddr *) &fromAddr))
  	//PELIGRO, hay alguien mandando info sin saber quien es
    	DieWithUserMessage("recvfrom()", "se ha recivido un paquete de una fuente desconocida");

  	freeaddrinfo(servAddr);

  	// Null-terminate received data
  	buffer[echoStringLen] = '\0';
  	// Print the echoed string
  	printf("Respuesta recivida: %s\n", buffer);

  	close(sock);
  	exit(0);
}
