<?php
	echo '<link rel=stylesheet href=myCSS.css>';
	$producto=$_POST['Objeto'];
	$categoria=$_POST['Categoria'];
	//Variable auxiliar
	$ifyes= $_POST['otro'];
	$estado=$_POST['Estado'];
	$precio=intval($_POST['Precio']);
	$rebaja=intval($_POST['Rebaja']);
	$rebajado=$precio - (($precio*$rebaja)/100);
	$envio=intval($_POST['IVA']);
	$precio_final=$rebajado + $envio;
	
	if($categoria == '1')
	{
		$categoria = 'Juegos &#x1F3AE;';
	}
	if($categoria == '2')
	{
		$categoria = 'Informatica &#x1F4BB;';
	}
	if($categoria == '3')
	{
		$categoria = 'Móviles  &#128241;';
	}
	if($categoria == '4')
	{
		$categoria = 'Moda &#x1F459;';
	}
	if($categoria == '5')
	{
		$categoria = 'Libros &#x1F4DA;';
	}
	if($categoria == '6')
	{
		$categoria = 'Música &#x1F3B6;';
	}
	if($categoria == '7')
	{
		$categoria = 'Imagen y sonido &#x1F3A7;';
	}
	if($categoria == '8')
	{
		$categoria = 'Casa &#x1F3E1;';
	}
	if($categoria == '9')
	{
		$categoria = 'Bebes &#x1F37C;';
	}
	if($categoria == '10')
	{
		$categoria = 'Deportes &#x1F3F8;';
	}
	if($categoria == '11')
	{
		$categoria = 'Mascotas &#x1F436;';
	}
	if($categoria == '12')
	{
		$categoria = 'Otros &#x2754;, en concreto con la categoria $ifyes';
	}
	
	if($estado == '1')
	{
		$estado = 'muy usado';
	}
	if($estado == '2')
	{
		$estado = 'usado';
	}
	if($estado == '3')
	{
		$estado = 'poco usado';
	}
	if($estado == '4')
	{
		$estado = 'nuevo';
	}
	
	echo "<p style='text-indent:10'> Se vende $producto dentro de la categoria $categoria. Su estado es $estado, por lo que el precio podira bajar hasta $rebajado euros."; 
	echo "Por lo tanto, rebajado y sumando los gastos de envio quedaría en $precio_final. Precio sin rebaja: $precio </p>";
	
	if($rebaja > 50)
	{
		echo "<p style='text-indent:10'> Lo estas regalando </p>";
		echo '<P style="text-align:center;"><img src="meme.jpg" width = "400" height = "341"></p>';
	}

?>
