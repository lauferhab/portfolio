#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "Practical.h"

// Incluir
static const int MAXPENDING = 5; //Maximas conexiones entrantes

int main(int argc, char *argv[]) {
	
	// Coger puerto que me dice el usuario
	
	// TCPEchoServer recibe el numero de puerto en el que escucho
	if(argc != 2)
		DieWithSystemMessage("Falta el puerto de entrada");
		
	in_port_t servPort = atoi(argv[1]);
	
	// CREAR EL SOCKET 
	int servSock;
	if ((servSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
		DieWithSystemMessage("socket () ha fallado al crear");
	
	printf("socket() correto \n");
	
	
	// Construir la estructura de dirección local

	struct sockaddr_in servAddr;
	// Reservar memoria
	
	memset(&servAddr, 0, sizeof(servAddr)); //Para que quepa toda la estructura
	
	// Tipo de IP
	servAddr.sin_family = AF_INET;
	
	// Dirección local
	servAddr.sin_addr.s_addr = htonl(INADDR_ANY); //la direccion mia (local)
	
	// Puerto local
	servAddr.sin_port = htons(servPort); //Ha entrado por la linea de comandos
	//Nos aseguramos de que tiene el formato correcto, htonl y htons
	
	
	// BIND (ASOCIAR A LA DIRECCIÓN Y PUERTO LOCAL)
	if (bind(servSock, (struct sockaddr*) &servAddr, sizeof(servAddr)) < 0)
		DieWithSystemMessage("bind() failed");
	
	printf("bind() correcto \n");
	
	// ESCUCHAR CONEXIONES ENTRANTES DE CLIENTES
	if (listen(servSock, MAXPENDING) < 0)
		DieWithSystemMessage("listen() failed");
		
	printf("listen() correcto \n");
	
	// Bucle infinito de recibir-enviar
	for (;;) {
		struct sockaddr_in clntAddr; // Client address: quiero si dirrecion porque quiero poner "un mensaje entrante de..."
		// Set length of client address structure (in-out parameter);
		socklen_t clntAddrLen = sizeof(clntAddr);
		
		// ACEPTAR CONEXIÓN ENTRANTE
		// Queda bloqueada hasta que llegue una conexión
		int clntSock = accept(servSock, (struct sockaddr*) &clntAddr, &clntAddrLen);
		//1) Socket (lo cree al principio)
		//2) direccion deonde almacenar la IP entrante
		//3) Tamaño de la direccion
		//Nunca llegaré aquí si no entra una conexión
		//ahora tenemos servSock y también clntSock
	
		if (clntSock < 0)
			DieWithSystemMessage("accept() failed");
		printf("accept() correcto \n");
		// Mostramos la IP del cliente conectado y el puerto (usan inet_ntop)
		
		char clntName[INET_ADDRSTRLEN]; // Esta string almacenará la dirección del cliente
		if (inet_ntop(AF_INET, &clntAddr.sin_addr.s_addr, clntName, sizeof(clntName))!= NULL)
			printf("Cliente conectado: %s con el puerto: %d \n", clntName, ntohs(clntAddr.sin_port));
		else
			puts("Fallo al obtener la dirección del cliente");
			
		/*----------------------------------MODIFICACION EJERCICIO 1----------------------------------*/
   		char* buffer2 = "Bienvenido al servidor"; //Cadena a enviar al cliente
   		ssize_t numBytes = send(clntSock, buffer2, 23, 0);
   		//1) socket Cliente
   		//2) cadena a enviar
  		//3) numero de bytes a enviar
   		// 4) configuracion de la flag inicializada a 0
  		/*----------------------------------MODIFICACION EJERCICIO 1----------------------------------*/

		HandleTCPClient(clntSock); //Implementa la loginca que yo quiero en la aplicaccion
	}
	//ESTA LINEA NUNCA SE EJECUTARA
}

//Funcion que trata con el Cliente
void HandleTCPClient(int clntSocket) {

   char buffer[BUFSIZE];
   
   // RECIBIR MENSAJE DEL CLIENTE
   ssize_t numBytesRcvd = recv(clntSocket, buffer, BUFSIZE, 0);
   // 1) socket Cliente
   // 2) donde almaceno lo recibido (string llamado buffer)
   // 3) tamaño de esa string
   // 4) configuracion de la flag inicializada a 0
   if (numBytesRcvd < 0)
      DieWithSystemMessage("recv() falló");

   // ENVIAR EL ECO Y SEGUIR RECIBIENDO HASTA QUE TERMINE
   
   while (numBytesRcvd > 0) { //si recibi algo lo envio de vuelta
      
      printf("Enviamos la cadena '%s' de vuelta \n",buffer);
      ssize_t numBytesSent = send(clntSocket, buffer, numBytesRcvd, 0);
      //1) socket Cliente
      //2) cadena a enviar
      //3) numero de bytes a enviar
      
      if (numBytesSent < 0) {
         DieWithSystemMessage("send() falló");
      }
      else if (numBytesSent != numBytesRcvd) {
         DieWithSystemMessage("send() envió un número de bytes no esperado");
      }
	  
	  // VER SI HAY MÁS DATOS QUE RECIBIR
	  
      numBytesRcvd = recv(clntSocket, buffer, BUFSIZE, 0);
      if (numBytesRcvd < 0) {
         DieWithSystemMessage("recv() failed");
      }
   }
   
   // CERRAR SOCKET
   
   close(clntSocket);
}

