#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/statvfs.h>

#include "Practical.h"

int32_t get_temperature()
{
	
	int32_t temp = 0;
	FILE *fp = NULL;
	
	if((fp = fopen("/sys/class/thermal/thermal_zone4/temp", "r")))
	{
		if(fscanf(fp, "%d", &temp))
		{
			temp /= 1000;
		}
		fclose(fp);
	}	
	return temp;
}

uint64_t get_free_ram()
{
	uint64_t freeram = 0;
	char *line = NULL;
	size_t len = 0;
	ssize_t nread = 0;
	FILE *fp = NULL;
	
	if((fp = fopen("/proc/meminfo", "r")))
	{
		while((nread = getline(&line, &len, fp)) != -1)
		{
			if(sscanf(line, "MemAvailable: %lu", &freeram))
			{
				break;
			}
		}
		free(line);
		fclose(fp);
	}
	return freeram;
}

uint64_t get_free_disk()
{
	uint64_t freedisk = 0;
	struct statvfs stats = {0};
	
	if(!statvfs("/", &stats))
	{
		freedisk = stats.f_bavail * stats.f_bsize;
	}
	
	return freedisk;
}

int main ()
{	

	char* servIP = "192.168.1.42"; //Direccion IP del Servidor
	in_port_t servPort = 5000;
	printf("Puerto elegido %d \n", servPort);//in_port_t es un tipo de datos "raro" para definir numero de puertos
	
	//Creamos las variables de temperatura, ram y disco. Cambiadas de unidad para que sean mas legibles
	int temp = 10; //get_temperature(); //Recoge la temperatura del dispositivo
	uint64_t ram = get_free_ram()/1024; //Recoge la memoria ram que esta libre del dispositivo
	uint64_t disk = get_free_disk()/1024/1024/1024; //Recoge la capacidad libre del disco del dispositivo
	
	char echoString[50]; //variable que almacenara los datos
	sprintf(echoString, "temp=%d&ram=%lu&disk=%lu\n", temp, ram, disk);
	size_t echoStringLen = strlen(echoString); //tamaño de la cadena
	
	printf("%s \n", echoString);
	
	//Crear el socket
	
	int sock = socket(AF_INET, SOCK_STREAM,IPPROTO_TCP);
	
	printf("El identificador del socket es %d \n", sock); //NO es el numero de puerto
	
	if(sock < 0)
	{
		DieWithSystemMessage("socket() ha fallado");
	}
	//Recordamos que AF_INET indica que es direccion IPv4
	
	struct sockaddr_in servAddr;
	memset(&servAddr, 0, sizeof(servAddr));
	
	servAddr.sin_family = AF_INET;
	
	//Usamos inet_pton para pasar IPs entendibles por mi a la maquina
	
	int rtnVal = inet_pton(AF_INET, servIP, &servAddr.sin_addr.s_addr);//Lo uso solo para comprobar que ha ido bien la conversion
	
	if(rtnVal < 1)
	{
		DieWithSystemMessage("Fallo al convertir la direccion");
	}
	
	printf("La direccion se ha convertido con existo \n");
	
	servAddr.sin_port = htons(servPort);
	
	//hotns se asegura de que el numero de puerto tenga el formato correcto
	
	//Conectar al servidor
	
	if(connect(sock, (struct sockaddr*) &servAddr, sizeof(servAddr)) < 0)
	{
		DieWithSystemMessage("La conexion ha fallado");
	}
	
	printf("Se ha conectado al servisor");
	
	//A PARTIR DE AQUI OBVIAREMOS ALGUNAS COMPROBACIONES
	//Enviar la cadena
	
	ssize_t numBytes = send(sock, echoString, echoStringLen, 0);
	
	//1) Identificador del socket
	//2) Mensaje a enviar
	//3) Tamaño del mensaje a enviar
	
	//se pone al final 0 porque no usamos ese argumento

	if(numBytes < 0) //Si el numero de bytes a enviar es negativo, es que ha habido un problema
	{
		DieWithSystemMessage("Ha fallado send()");
	}
	else if (numBytes != echoStringLen)
	{
		DieWithSystemMessage("Ha enviado algo, pero no lo que pedi");
	}
	
	//Recibir la cadena de vuelta (debe de ser la misma)
	
	unsigned int totalBytesRcvd = 0;
	
	printf("Comenzamos a recibir \n");

	while (totalBytesRcvd < echoStringLen) // o bien menor que numBytes
	{
		char buffer[BUFSIZE]; //La cadena recibida
		int numBytesRecv;
		//BUFFSIZE es un valor del S.O qeu dice el tamaño maximo que puede terne un mensaje recibido
		
		numBytesRecv = recv(sock, buffer, BUFSIZE - 1, 0);
		
		//1) El identificador del socket
		//2) Donde almaceno la cadena recibida
		//3) El tamaño de la cadena recibida
		
		//El tamaño recibido es BUFFSIZE - 1 porque cuando enviamos una cadena, no se 
		//envia el caracter de terminacion de las strings
		
		//si todo va bien, va a recibir lo que envio
		
		//Actualizo el contador
		
		totalBytesRcvd += numBytesRecv;
		
		printf("Cadena recibida: %s \n", buffer);
	}
	
	//Cerrar el socket
	
	close(sock);
	
	return(0);

}
