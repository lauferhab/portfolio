#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "Practical.h"

int main (int argc, char *argv[])
{
	//Antes de crear el socket, vamos a coger la informacion que viene del usuario
	
	if(argc < 3 || argc > 4)
	{
		DieWithUserMessage("Los parametros deben ser", "<DIRECCION SERVIDOR>, <PALABRA> y opcionalmente el <PUERTO>"); 
	}
	
	char* servIP = argv[1]; //Direccion IP del Servidor
	char* echoString = argv[2]; //Cadena a enviar y que me debe volver igual
	
	//Tengo que almacenar el tamaño de la cadena a enviar
	//reciba de vuelta la cadena, sepa que tiene el tamaño adecuado
	
	size_t echoStringLen = strlen(echoString);
	
	printf("El tamaño de la cadena es %d \n", (int) echoStringLen);
	
	in_port_t servPort = (argc == 4) ? atoi(argv[3]) : 7;
	
	printf("Puerto elegido %d \n", servPort);
	//quiero que valga lo que me hayan pasado en argv[3], y si no existe, 7 
	//in_port_t es un tipo de datos "raro" para definir numero de puertos

	//Crear el socket
	
	int sock = socket(AF_INET, SOCK_STREAM,IPPROTO_TCP);
	
	printf("El identificador del socket es %d \n", sock); //NO es el numero de puerto
	
	if(sock < 0)
	{
		DieWithSystemMessage("socket() ha fallado");
	}
	//Recordamos que AF_INET indica que es direccion IPv4
	
	struct sockaddr_in servAddr;
	memset(&servAddr, 0, sizeof(servAddr));
	
	servAddr.sin_family = AF_INET;
	
	//Usamos inet_pton para pasar IPs entendibles por mi a la maquina
	
	int rtnVal = inet_pton(AF_INET, servIP, &servAddr.sin_addr.s_addr);//Lo uso solo para comprobar que ha ido bien la conversion
	
	if(rtnVal < 1)
	{
		DieWithSystemMessage("Fallo al convertir la direccion");
	}
	
	printf("La direccion se ha convertido con existo \n");
	
	servAddr.sin_port = htons(servPort);
	
	//hotns se asegura de que el numero de puerto tenga el formato correcto
	
	//Conectar al servidor
	
	if(connect(sock, (struct sockaddr*) &servAddr, sizeof(servAddr)) < 0)
	{
		DieWithSystemMessage("La conexion ha fallado");
	}
	printf("La conexion se ha establecido con existo \n");
	/*----------------------------------MODIFICACION EJERCICIO 1----------------------------------*/
	//RECIBIMOS EL MENSAJE DE BIENBENIDA
	char string[23]; 
	int numBytesRecv2;
	numBytesRecv2 = recv(sock, string, 23, 0);
	printf("%s \n", string);
	/*----------------------------------MODIFICACION EJERCICIO 1----------------------------------*/
	
	//A PARTIR DE AQUI OBVIAREMOS ALGUNAS COMPROBACIONES
	//Enviar la cadena
	
	ssize_t numBytes = send(sock, echoString, echoStringLen, 0);
	
	//1) Identificador del socket
	//2) Mensaje a enviar
	//3) Tamaño del mensaje a enviar
	
	//se pone al final 0 porque no usamos ese argumento

	if(numBytes < 0) //Si el numero de bytes a enviar es negativo, es que ha habido un problema
	{
		DieWithSystemMessage("Ha fallado send()");
	}
	else if (numBytes != echoStringLen)
	{
		DieWithSystemMessage("Ha enviado algo, pero no lo que pedi");
	}
	
	//Recibir la cadena de vuelta (debe de ser la misma)
	unsigned int totalBytesRcvd = 0;
	printf("Comenzamos a recibir \n");
	while (totalBytesRcvd < echoStringLen) // o bien menor que numBytes
	{
		char buffer[BUFSIZE]; //La cadena recibida
		int numBytesRecv;
		//BUFFSIZE es un valor del S.O que dice el tamaño maximo que puede terne un mensaje recibido
		
		numBytesRecv = recv(sock, buffer, BUFSIZE - 1, 0);
		
		//1) El identificador del socket
		//2) Donde almaceno la cadena recibida
		//3) El tamaño de la cadena recibida
		
		//El tamaño recibido es BUFFSIZE - 1 porque cuando enviamos una cadena, no se 
		//envia el caracter de terminacion de las strings
		
		//si todo va bien, va a recibir lo que envio
		
		//Actualizo el contador
		
		totalBytesRcvd += numBytesRecv;
		
		printf("Cadena recibida: %s \n", buffer);
	}
	
	//Cerrar el socket
	
	close(sock);
	
	return(0);

}
