<?php
	echo "<link rel=stylesheet href=myCSS.css>";
	$temp=$_POST['Temp'];
	$ram=$_POST['Ram'];
	$disk=$_POST['Disk'];
	
	//servidor TCP en PHP

	$host = "0.0.0.0";
	$port = "5000";
	$socket = socket_create(AF_INET,SOCK_STREAM,0); // con sock_stream ya sabe que es TCP
	echo "<label style=color:green;>Socket creado con éxito<br></label>";
	socket_bind($socket,$host,$port) or die("<label style=color:red;>Error en el bind<br></label>");
	echo "<label style=color:green;>Socket bindeado con éxito<br></label>";
	socket_listen($socket);
	echo "<label style=color:green;>Socket escuchando en el puerto $port<br></label>";
	$client = socket_accept($socket);
	echo "<label style=color:green;>Cliente aceptado:<br><br></label>";
	$message=socket_read($client,100);
	//echo $message;

	echo"<h2>MÉTRICAS DEL DISPOSITIVO</h2>";
	echo"<p style='font-style:italic;'>Métricas Obtenidas</p>";
	parse_str($message, $datos);
	$temperatura = $datos['temp'];
	$memoriaRam = $datos['ram'];
	$disco = $datos['disk'];
	echo "<div style='margin: 0 auto;width: 700px;padding: 1em;border: 2px dotted lightSeaGreen;border-radius: 2em;font-family: helvetica;'>La temperatura del dispositivo es: $temperatura <br> 
	La memoria RAM disponible del dispositivo es: $memoriaRam <br>
	El disco disponible del dispositivo es: $disco </div>";
	
	socket_write($client,"Datos recibidos",100);

	socket_close($socket);

?>